
def e_quadrado():
    valor = float(input("Digite o valor: "))
    quadrado = valor ** 2
    return quadrado

resultado = e_quadrado()
print("O numero quadrado é: ", resultado)
