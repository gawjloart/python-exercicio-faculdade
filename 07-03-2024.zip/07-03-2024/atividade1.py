def mensagem(nome):
    return f"Seja bem vindo ao sistema, {nome}!"

nome = input("Qual seu nome? ")
print(mensagem(nome))